import unittest
import numpy as np
from scipy.integrate import quad
from numpy.testing import assert_allclose
from src.models import BarotropicPowerDiffusionParams,BarotropicPowerDiffusionModel
from src.observations import CoreBackground,DomainError,Gaussian,BAOData,SNData,joint_chi2,fit_background

def background(w=-1,om=.3,H0=70):
    return CoreBackground(BarotropicPowerDiffusionModel(BarotropicPowerDiffusionParams(w,0,1,1)),H0,om)

class ObservationTests(unittest.TestCase):
    def test_lcdm_limit_and_independent_quadrature(self):
        b=background();z=np.array([.01,.5,1,2.33]);d=b.distances(2.33)
        assert_allclose(b.E(z),np.sqrt(.3*(1+z)**3+.7))
        reference=[299792.458/70*quad(lambda t:1/np.sqrt(.3*(1+t)**3+.7),0,v,epsabs=1e-12)[0] for v in z]
        assert_allclose(d.DM(z),reference,rtol=2e-8)
        assert_allclose(d.DL(z)/(1+z)**2,d.DM(z)/(1+z))

    def test_single_fluid_is_core_normalization(self):
        b=background(-1.2,0);z=np.array([0,.5,2])
        assert_allclose(b.E(z),(1+z)**(-.3),rtol=1e-12)

    def test_de_sitter_distance(self):
        d=background(-1,0).distances(3)
        assert_allclose(d.DM([.1,1,3]),299792.458/70*np.array([.1,1,3]),rtol=1e-12)

    def test_offset_profile_and_correlated_chi2(self):
        C=np.array([[2,.5],[.5,1.]])
        g=Gaussian([2,3],C);p=np.array([.4,.9]);r=g.y-p
        self.assertAlmostEqual(g.chi2(p),r@np.linalg.solve(C,r))
        chi,M=g.profile_offset(p)
        self.assertAlmostEqual(chi,g.chi2(p+M))
        self.assertAlmostEqual(g.profile_offset(p+7)[0],chi)
        with self.assertRaises(ValueError):Gaussian([1,2],[[1,.5],[.1,1]])

    def test_sn_h0_degeneracy_and_heliocentric_factor(self):
        z=np.array([.05,.2,.8]);zh=z+.002
        d=background().distances(1)
        assert_allclose(d.DL(z,zh)/d.DL(z),(1+zh)/(1+z))
        sn=SNData(z,zh,d.mu(z,zh)-19.3,np.eye(3)*.01)
        self.assertLess(sn.profile(d)[0],1e-20)
        self.assertLess(sn.profile(background(H0=80).distances(1))[0],1e-20)

    def test_bao_h0_rd_degeneracy(self):
        z=[.3,.7,1.];k=['DV_over_rs','DM_over_rs','DH_over_rs']
        b=BAOData(z,[1,1,1],k,np.eye(3))
        assert_allclose(b.prediction(background(H0=70).distances(1),150),
                        b.prediction(background(H0=75).distances(1),140))

    def test_branch_end_rejected(self):
        m=BarotropicPowerDiffusionModel(BarotropicPowerDiffusionParams(-1.2,4,-1,1))
        with self.assertRaises(DomainError):CoreBackground(m).distances(100)

    def test_synthetic_recovery(self):
        z=[.3,.5,.8,1.5,2.3];k=['DV_over_rs','DM_over_rs','DH_over_rs','DM_over_rs','DH_over_rs']
        bao=BAOData(z,np.ones(5),k,np.eye(5)*.01)
        bao=BAOData(z,bao.prediction(background(om=.32).distances(2.3),145),k,np.eye(5)*.01)
        result=fit_background(lambda t:(background(om=t[0]),t[1]),[[.25,150],[.4,130]],[(.1,.5),(110,180)],bao=bao)
        assert_allclose(result['parameters'],[.32,145],rtol=1e-4)

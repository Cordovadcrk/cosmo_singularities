import subprocess
import sys
import unittest
from enum import Enum

from src.singularities import KnownCosmologicalBehavior, normalize_behavior_label


class NotebookCompatibilityTests(unittest.TestCase):
    def test_enum_reload_in_fresh_process(self):
        # Reproduce el error de notebooks sin contaminar las demás pruebas.
        code = '''
import importlib
import src.singularities as s
from src.classifiers import ClassificationResult, ClassificationStatus, KnownCosmologicalBehavior, SingularityType
importlib.reload(s)
r = ClassificationResult(standard_type=SingularityType.TYPE_I,
    behavior_label=KnownCosmologicalBehavior.TYPE_I_BIG_RIP,
    status=ClassificationStatus.ROBUST,is_singularity=True,finite_time=True,confidence=1)
assert r.as_dict()['behavior_label'] == 'type_i_big_rip'
assert isinstance(r.status,s.ClassificationStatus)
assert isinstance(r.standard_type,s.SingularityType)
'''
        result = subprocess.run([sys.executable,'-c',code],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_serialized_labels_remain_stable(self):
        for member in KnownCosmologicalBehavior:
            self.assertEqual(normalize_behavior_label(member),normalize_behavior_label(member.value))
        self.assertEqual(normalize_behavior_label('little_rip'),'little rip')

    def test_unrelated_enums_not_accepted(self):
        class Foreign(Enum):
            RIP = 'type_i_big_rip'
        with self.assertRaises(TypeError):
            normalize_behavior_label(Foreign.RIP)

"""Regresiones contra soluciones exactas y ecuaciones de fondo independientes."""
import math
import unittest

import numpy as np
from numpy.testing import assert_allclose

from src.models import (PhantomQ0Model, PhantomQ0Params, PhantomQAlphaRhoModel,
                        PhantomQAlphaRhoParams, BarotropicPowerDiffusionModel,
                        BarotropicPowerDiffusionParams)
from src.classifiers import classify_phantom_q0_by_nu
from src.barotropic_analysis import state_at_density, analyze_barotropic_case
from src.datasets import build_phantom_q0_dataset


class ExactPhantomTests(unittest.TestCase):
    def test_future_classification_and_time(self):
        for nu in [-2, -0.1, 0, 0.25, 0.5, math.nextafter(0.5, math.inf),
                   0.75, 1, math.nextafter(1, math.inf), 2]:
            expected = "Non singular" if nu <= .5 else "Type I / Big Rip" if nu <= 1 else "Type III"
            with self.subTest(nu=nu):
                self.assertEqual(classify_phantom_q0_by_nu(nu).value, expected)
                model = PhantomQ0Model(PhantomQ0Params(A=.2, nu=nu, rho0=2, t0=3))
                self.assertEqual(model.singular_time() is None, nu <= .5)
                self.assertGreater(model.rho_of_t(3.01), 2)

    def test_linear_diffusion_reduces_to_q0(self):
        for nu in [-1, 0, .5, 1, 2]:
            left = PhantomQ0Model(PhantomQ0Params(.3, nu, 1.4, a0=2, t0=3))
            right = PhantomQAlphaRhoModel(PhantomQAlphaRhoParams(A=.3, nu=nu, alpha=0, rho0=1.4, a0=2, t0=3))
            assert_allclose(left.evaluate_background_t([3, 3.1, 3.2]),
                            right.evaluate_background_t([3, 3.1, 3.2]), rtol=1e-13)
            self.assertEqual(left.singular_time(), right.singular_time())

    def test_exact_solutions_satisfy_continuity_and_raychaudhuri(self):
        for nu in [-1, .25, .5, 1, 2]:
            for alpha in [-.5, 0, 2]:
                model = PhantomQAlphaRhoModel(PhantomQAlphaRhoParams(A=.2, nu=nu, alpha=alpha, rho0=1.3))
                t, step = .2, 1e-5
                rho = model.rho_of_t(t)
                drho = (model.rho_of_t(t+step)-model.rho_of_t(t-step))/(2*step)
                self.assertAlmostEqual((1+alpha)*drho/(3*.2*model.hubble(rho)*rho**nu), 1, places=8)
                dh = (model.hubble(model.rho_of_t(t+step))-model.hubble(model.rho_of_t(t-step)))/(2*step)
                self.assertAlmostEqual(dh/model.hdot(rho), 1, places=8)
                self.assertAlmostEqual(model.rho_of_a(model.scale_factor_from_rho(rho)), rho, places=12)

    def test_stability_near_logarithmic_exponents(self):
        for center in [.5, 1]:
            ref = PhantomQ0Model(PhantomQ0Params(.3, center, 2))
            for delta in [-1e-10, -1e-14, 1e-14, 1e-10]:
                model = PhantomQ0Model(PhantomQ0Params(.3, center+delta, 2))
                assert_allclose(model.rho_of_t(.2), ref.rho_of_t(.2), rtol=1e-9)
                assert_allclose(model.log_a_of_rho(3), ref.log_a_of_rho(3), rtol=1e-9)

    def test_q0_dataset_stops_before_big_rip(self):
        data = build_phantom_q0_dataset([1], [.75, 1, 2], n_points=30)
        self.assertTrue(data.valid_solution.all(), data.error_message.to_list())
        self.assertTrue((data.t_eval_max < data.singular_time).all())


class BarotropicRegressionTests(unittest.TestCase):
    def test_beta_one_exact_time_and_scale(self):
        p = BarotropicPowerDiffusionParams(omega=-1.2, alpha=-.3, beta=1, rho0=2, a0=3)
        for target in [4, 1e3, 1e6]:
            result = state_at_density(p, target)
            expected_t = 2*math.sqrt(.7)/(math.sqrt(3)*.2)*(2**(-.5)-target**(-.5))
            self.assertAlmostEqual(result['t'], expected_t, places=10)
            self.assertAlmostEqual(result['log_a'], math.log(3)+.7/(3*.2)*math.log(target/2), places=10)

    def test_beta_one_slow_scale_growth_is_not_new_behavior(self):
        p = BarotropicPowerDiffusionParams(-1.2, -.9, 1, 1)
        analysis = analyze_barotropic_case(p, t_end=.1, n_points=20, density_decades=3)
        self.assertEqual(analysis.classification.behavior_label, 'type_i_big_rip')
        self.assertEqual(analysis.classification.evidence['analytic_basis']['a_limit'], 'diverges')
        self.assertIn('a', analysis.classification.observed_behavior)

    def test_short_diffusion_run_keeps_analytic_and_numeric_evidence_separate(self):
        p = BarotropicPowerDiffusionParams(-1.2, 4, -1, 1)
        analysis = analyze_barotropic_case(p, t_end=.1, n_points=20, density_decades=3)
        result = analysis.classification
        self.assertEqual(result.behavior_label, 'diffusion_driven_infinite_time_rip')
        self.assertFalse(result.finite_time)
        self.assertEqual(result.status.value, 'provisional')
        self.assertEqual(analysis.summary_dict()['classification_basis'], 'analytic_with_numerical_diagnostics')
        self.assertEqual(result.evidence['analytic_basis']['Hdot_limit'], 'zero')

    def test_de_sitter_uses_time_not_density_as_clock(self):
        p = BarotropicPowerDiffusionParams(-1, .3, 2, 1)
        m = BarotropicPowerDiffusionModel(p)
        with self.assertRaisesRegex(ValueError, 'rho es constante'):
            m.log_a_of_rho(1)
        bg = m.solve_background_t(1, n_points=20)
        assert_allclose(bg.rho, 1, rtol=1e-12)
        assert_allclose(bg.a, np.exp(m.hubble(1)*bg.t), rtol=1e-8)
        analysis = analyze_barotropic_case(p, t_end=.1, n_points=20)
        self.assertEqual(analysis.summary_dict()['behavior_label'], 'de_sitter')

    def test_background_residuals_and_beta2(self):
        for alpha, beta in [(.3, 1.5), (.3, 2), (.3, 3), (4, -1), (-.3, 1.5)]:
            p = BarotropicPowerDiffusionParams(-1.2, alpha, beta, 1)
            model = BarotropicPowerDiffusionModel(p)
            bg = model.solve_background_t(.1, n_points=30)
            assert_allclose(3*bg.H**2, bg.rho+alpha*bg.rho**beta, rtol=1e-12)
            assert_allclose(bg.Hdot, .1*bg.rho, rtol=1e-12)
        # A beta=2, dt/d ln(rho) -> alpha*beta/(sqrt(3)*gamma*sqrt(alpha)).
        p = BarotropicPowerDiffusionParams(-1.2, .3, 2, 1)
        t1, t2 = [state_at_density(p, r)['t'] for r in [1e6, 1e8]]
        predicted = .6/(math.sqrt(3)*.2*math.sqrt(.3))*math.log(100)
        self.assertAlmostEqual((t2-t1)/predicted, 1, places=9)

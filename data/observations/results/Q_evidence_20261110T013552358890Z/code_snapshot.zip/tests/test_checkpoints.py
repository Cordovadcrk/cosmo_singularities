import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from src.parameter_space import build_parameter_grid, analyze_parameter_grid


class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'scan.csv'
        # Excluido: no gastar integración en pruebas de persistencia.
        self.grid = build_parameter_grid([-2], [1], [-1.2])

    def run_scan(self, grid=None, **kwargs):
        return analyze_parameter_grid(self.grid if grid is None else grid,
                                      checkpoint_path=self.path, verbose=False, **kwargs)

    def test_roundtrip_and_identical_explicit_defaults(self):
        first = self.run_scan()
        second = self.run_scan(analysis_kwargs={'t_end':20.0})
        self.assertEqual(first.point_id.to_list(), second.point_id.to_list())
        self.assertEqual(second.behavior_label.iloc[0], 'invalid_initial_domain')
        self.assertIn('_checkpoint_signature', pd.read_csv(self.path))

    def test_reject_changed_grid_or_configuration_preserving_file(self):
        self.run_scan()
        original = self.path.read_bytes()
        for grid, kwargs in [(build_parameter_grid([-3], [1], [-1.2]), {}),
                             (self.grid, {'analysis_kwargs':{'rtol':1e-8}})]:
            with self.assertRaisesRegex(ValueError, 'incompatible'):
                self.run_scan(grid, **kwargs)
            self.assertEqual(self.path.read_bytes(), original)

    def test_reject_legacy_checkpoint_preserving_file(self):
        self.grid.to_csv(self.path,index=False)
        original = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, 'histórico'):
            self.run_scan()
        self.assertEqual(self.path.read_bytes(),original)

    def test_retry_failed_rows(self):
        grid = build_parameter_grid([.3], [1], [-1.2])
        with patch('src.parameter_space.analyze_barotropic_case', side_effect=RuntimeError('failure')) as call:
            first = self.run_scan(grid)
            self.assertEqual(call.call_count,1)
            self.assertEqual(first.behavior_label.iloc[0],'analysis_error')
        with patch('src.parameter_space.analyze_barotropic_case', side_effect=RuntimeError('retried')) as call:
            second = self.run_scan(grid)
            self.assertEqual(call.call_count,1)
            self.assertIn('retried',second.error.iloc[0])
        with patch('src.parameter_space.analyze_barotropic_case') as call:
            self.run_scan(grid,retry_failed=False)
            call.assert_not_called()

    def test_invalid_options_fail_before_writing(self):
        with self.assertRaises(TypeError):
            self.run_scan(analysis_kwargs={'unknown_option':1})
        self.assertFalse(self.path.exists())

    def test_duplicate_ids_rejected(self):
        with self.assertRaisesRegex(ValueError,'únicos'):
            self.run_scan(pd.concat([self.grid,self.grid],ignore_index=True))

    def test_atomic_write_failure_preserves_previous(self):
        self.run_scan()
        original = self.path.read_bytes()
        with patch('src._checkpoints.os.replace',side_effect=OSError('disk failure')):
            with self.assertRaises(OSError):
                self.run_scan()
        self.assertEqual(self.path.read_bytes(),original)
        self.assertFalse(list(self.path.parent.glob('*.tmp')))

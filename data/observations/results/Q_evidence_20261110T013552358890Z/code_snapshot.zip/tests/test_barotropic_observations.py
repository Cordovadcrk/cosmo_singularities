import unittest
import numpy as np
from numpy.testing import assert_allclose
from scipy.integrate import solve_ivp
from src.observations import barotropic_background,degeneracies,DomainError

class BarotropicObservationsTests(unittest.TestCase):
    def test_constant_Q(self):
        for w in [-1.3,-1.,-.8]:
            b=barotropic_background(.3,w,.4,0)
            z=np.array([0,.3,2.3])
            assert_allclose(b.density(z),(1+z)**(3*(1+w)))
            assert_allclose(b.E(z)**2,.3*(1+z)**3+.7*((1+z)**(3*(1+w))+.4)/1.4)
            assert_allclose(b.dark_sector(z)['Qdot_over_3H03'],0)

    def test_exact_degeneracies(self):
        z=np.linspace(0,2.3,30)
        for alpha,beta in [(.4,2),(4,-1),(-.2,2)]:
            assert_allclose(barotropic_background(.3,-1,alpha,beta).E(z),np.sqrt(.3*(1+z)**3+.7),rtol=1e-12)
        a=barotropic_background(.3,-1.2,1,1)
        b=barotropic_background(.3,-1.1,0,1)
        assert_allclose(a.E(z),b.E(z),rtol=1e-12)
        self.assertTrue(degeneracies(-1,0,1))

    def test_against_independent_continuity_integration(self):
        # Independent integration in N, both sides of -1 and both D branches.
        for w,alpha,beta in [(-1.2,.3,2),(-.8,.3,2),(-1.1,4,-1),(-.9,4,-1)]:
            b=barotropic_background(.3,w,alpha,beta)
            N=np.linspace(0,-np.log(2),100)
            sol=solve_ivp(lambda n,x:-3*(1+w)*x/(1+alpha*beta*x**(beta-1)),
                          (0,N[-1]),[1.],t_eval=N,rtol=1e-11,atol=1e-12)
            self.assertTrue(sol.success)
            assert_allclose(b.density(np.expm1(-N)),sol.y[0],rtol=2e-9)

    def test_transfer_and_total_hdot(self):
        for w in [-1.2,-.8]:
            b=barotropic_background(.3,w,.3,2)
            z=np.array([.1,.5,1.]);h=1e-5;d=b.dark_sector(z)
            qprime=(b.dark_sector(z+h)['Q_over_3H02']-b.dark_sector(z-h)['Q_over_3H02'])/(2*h)
            assert_allclose(d['Qdot_over_3H03'],-(1+z)*b.E(z)*qprime,rtol=2e-8)
            eprime=(b.E(z+h)-b.E(z-h))/(2*h)
            assert_allclose(d['Hdot_over_H02'],-(1+z)*b.E(z)*eprime,rtol=2e-8)
            self.assertTrue(np.all(np.sign(d['w_de']+1)==np.sign(w+1)))

    def test_branch_guards(self):
        for args in [(.3,-1,-1,2),(.3,-1,1,-1)]:
            with self.assertRaises(DomainError):barotropic_background(*args)
        with self.assertRaises(DomainError):barotropic_background(.3,-1,4,-1,branch=1)

    def test_lambert_near_fold_preserves_initial_density(self):
        from scipy.optimize import brentq
        b=barotropic_background(.3,-.65,1.65,(-1-2e-6)/1.65)
        self.assertEqual(float(b.density(0)),1.)
        p=b.model.params
        z=1e-12
        # Solve the implicit N(rho) relation independently, in logarithmic density.
        target=-3*(1+p.omega)*np.log(1/(1+z))
        def residual(u):
            return u+p.alpha*p.beta/(p.beta-1)*np.expm1((p.beta-1)*u)-target
        u=brentq(residual,-.01,0,xtol=1e-15)
        assert_allclose(b.density(z),np.exp(u),rtol=2e-10)
        d=b.dark_sector(0)
        expected=-3*(1+p.omega)*(.7/(1+p.alpha))*(p.alpha*p.beta)/(1+p.alpha*p.beta)
        assert_allclose(d['Qdot_over_3H03'],expected,rtol=1e-10)

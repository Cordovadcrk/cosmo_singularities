import unittest
import numpy as np
from numpy.testing import assert_allclose
from scipy.optimize import minimize_scalar
from src.observations import BAOData,SNData,barotropic_background
from src.observations.inference import ProfileLikelihood,PowerSpec,search_profile

class InferenceTests(unittest.TestCase):
    def test_bao_analytic_profile_correlated(self):
        bg=barotropic_background(.3,-.9,.2,2)
        z=np.array([.2,.5,1.]);k=['DV_over_rs','DM_over_rs','DH_over_rs']
        C=np.array([[.04,.005,0],[.005,.09,.01],[0,.01,.04]])
        dummy=BAOData(z,[1,1,1],k,C)
        data=BAOData(z,dummy.prediction(bg.distances(1),147)+[.1,-.2,.05],k,C)
        profile=ProfileLikelihood(bao=data).evaluate(bg)
        d=bg.distances(1,1025)
        fit=minimize_scalar(lambda s:data.chi2(data.prediction(d,s/70)),bounds=(5000,15000),method='bounded')
        assert_allclose(profile['H0_rd_km_s'],fit.x,rtol=1e-7)
        assert_allclose(profile['chi2'],fit.fun,atol=1e-9)

    def test_sn_profile_equals_projected_inverse(self):
        C=np.array([[.02,.003,0],[.003,.03,.002],[0,.002,.01]])
        b=barotropic_background(.3,-.9,0,1);z=np.array([.03,.3,1.])
        mu=b.distances(1,1025).mu(z)
        data=SNData(z,z,mu-19.2+[.1,-.2,.05],C)
        inv=np.linalg.inv(C);one=np.ones(3)
        projected=inv-np.outer(inv@one,inv@one)/(one@inv@one)
        r=data.y-mu
        assert_allclose(ProfileLikelihood(sn=data).evaluate(b)['chi2'],r@projected@r,atol=1e-9)

    def test_linear_family_identical_with_free_effective_w(self):
        z=np.linspace(0,2.3,200)
        we=-.9
        for a in [-.7,.2,4,12]:
            w=(1+a)*we+a
            assert_allclose(barotropic_background(.3,w,a,1).E(z),barotropic_background(.3,we,0,1).E(z),rtol=1e-12)

    def test_both_negative_components(self):
        a=PowerSpec(branch='negative_alpha_positive').background([.3,-.9,2,-1])
        b=PowerSpec(branch='negative_alpha_negative').background([.3,-1.1,-.6,2])
        self.assertLess(a.model.D(1),0);self.assertLess(b.model.D(1),0)

    def test_synthetic_noiseless_recovery_with_scale_profile(self):
        truth=barotropic_background(.32,-.85,0,1)
        z=np.array([.1,.3,.5,.8,1.2,1.6,2.3]);k=['DV_over_rs']*len(z)
        tmp=BAOData(z,np.ones(len(z)),k,np.eye(len(z))*.0001)
        data=BAOData(z,tmp.prediction(truth.distances(2.3,8193),145),k,tmp.cov)
        r=search_profile(PowerSpec(kind='noQ'),ProfileLikelihood(bao=data),maxiter=45,starts=[[.3,-1]])
        assert_allclose(r['parameters'],[.32,-.85],atol=5e-5)
        assert_allclose(r['H0_rd_km_s'],70*145,rtol=1e-5)

    def test_CPL_constant_limit_reuses_distance_engine(self):
        from src.observations.constraints import CPLBackground
        for w in [-1.2,-1.,-.8]:
            z=np.array([0,.1,.5,1.,2.3])
            c=CPLBackground(.3,w,0)
            b=barotropic_background(.3,w,0,1)
            assert_allclose(c.E(z),b.E(z),rtol=1e-12)
            assert_allclose(c.distances(2.3).DM(z),b.distances(2.3).DM(z),rtol=1e-12)

    def test_synthetic_diffusion_amplitude_recovery(self):
        from src.observations.constraints import FixedShape
        truth=barotropic_background(.31,-.5,.4,-2.)
        z=np.array([.05,.1,.2,.4,.7,1.,1.5,2.3])
        k=['DM_over_rs','DH_over_rs']*4
        tmp=BAOData(z,np.ones(len(z)),k,np.eye(len(z))*.0001)
        data=BAOData(z,tmp.prediction(truth.distances(2.3,8193),146),k,tmp.cov)
        spec=FixedShape(PowerSpec(beta_fixed=-2.),'omega',-.5)
        r=search_profile(spec,ProfileLikelihood(bao=data),maxiter=45,starts=[[.28,.35],[.35,.45]])
        assert_allclose(r['parameters'],[.31,.4],atol=1e-5)
        assert_allclose(r['H0_rd_km_s'],70*146,rtol=1e-6)
